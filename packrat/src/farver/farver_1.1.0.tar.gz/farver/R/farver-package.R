#' @useDynLib farver
#' @import Rcpp
'_PACKAGE'
library(testthat)
library(farver)

test_check("farver")

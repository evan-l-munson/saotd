#ifndef COMMON_H
#define COMMON_H

#include <math.h>

double log_sum(double, double);

#endif
